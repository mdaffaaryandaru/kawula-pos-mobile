import 'dart:async';

// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

// Project imports:
import 'package:kawula_pos/features/auth/domain/entities/auth_user.dart';
import 'package:kawula_pos/features/auth/presentation/bloc/auth_cubit.dart';
import 'package:kawula_pos/features/balances/domain/repositories/balances_repository.dart';
import 'package:kawula_pos/features/dashboard/presentation/pages/admin_dashboard_page.dart';
import 'package:kawula_pos/features/dashboard/presentation/widgets/offline_sales_tab.dart';
import 'package:kawula_pos/features/offline/domain/services/offline_network_status_controller.dart';
import 'package:kawula_pos/features/shifts/domain/repositories/shifts_repository.dart';
import 'package:kawula_pos/features/shifts/presentation/bloc/shifts_cubit.dart';
import 'package:kawula_pos/features/shifts/presentation/bloc/shifts_state.dart';
import 'package:kawula_pos/features/store_settings/domain/repositories/auto_close_settings_provider.dart';
import 'package:kawula_pos/features/transactions/domain/repositories/checkout_repository.dart';
import 'package:kawula_pos/features/offline/domain/repositories/offline_transaction_queue_repository.dart';
import 'package:kawula_pos/features/offline/domain/services/offline_transaction_sync.dart';
import 'package:kawula_pos/features/offline/application/offline_sales_repository_factory.dart';
import 'package:kawula_pos/features/transactions/presentation/pages/admin_transaction_report_page.dart';

class CashierNavigationPage extends StatefulWidget {
  const CashierNavigationPage({
    super.key,
    required this.user,
    this.offlineNetworkStatusController,
    required this.shiftsRepository,
    required this.checkoutRepository,
    required this.offlineTransactionQueueRepository,
    required this.offlineSalesRepositoryFactory,
    required this.balancesRepository,
    this.offlineTransactionSyncService,
    required this.autoCloseSettingsProvider,
  });

  final AuthUser user;
  final OfflineNetworkStatusController? offlineNetworkStatusController;
  final ShiftsRepository shiftsRepository;
  final CheckoutRepository checkoutRepository;
  final OfflineTransactionQueueRepository offlineTransactionQueueRepository;
  final OfflineSalesRepositoryFactory offlineSalesRepositoryFactory;
  final BalancesRepository balancesRepository;
  final OfflineTransactionSync? offlineTransactionSyncService;
  final AutoCloseSettingsProvider autoCloseSettingsProvider;

  @override
  State<CashierNavigationPage> createState() => _CashierNavigationPageState();
}

class _CashierNavigationPageState extends State<CashierNavigationPage>
    with WidgetsBindingObserver {
  int _selectedIndex = 0;
  late final ShiftsCubit _shiftsCubit;
  late final List<Widget?> _pages;
  final Connectivity _connectivity = Connectivity();
  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  Timer? _recoveryTimer;
  bool _hasNetworkConnectivity = false;
  bool _isVerifyingServer = false;

  @override
  void initState() {
    super.initState();
    _shiftsCubit = ShiftsCubit(widget.shiftsRepository)..loadActive();
    _pages = List<Widget?>.filled(3, null);
    _pages[0] = _pageAt(0);
    if (widget.user.role == 'Kasir' &&
        widget.offlineNetworkStatusController != null) {
      WidgetsBinding.instance.addObserver(this);
      _connectivitySubscription = _connectivity.onConnectivityChanged.listen(
        _onConnectivityChanged,
        onError: (Object error, StackTrace stackTrace) {
          widget.offlineNetworkStatusController?.markOffline();
          if (mounted) setState(() {});
        },
      );
      unawaited(_refreshConnectivity());
      _recoveryTimer = Timer.periodic(
        const Duration(minutes: 1),
        (_) => _retryRecoveryWhenOffline(),
      );
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _connectivitySubscription?.cancel();
    _recoveryTimer?.cancel();
    _shiftsCubit.close();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      unawaited(_refreshConnectivity());
    }
  }

  Future<void> _refreshConnectivity() async {
    if (widget.user.role != 'Kasir' ||
        widget.offlineNetworkStatusController == null) {
      return;
    }
    try {
      final results = await _connectivity.checkConnectivity();
      await _onConnectivityChanged(results);
    } on Exception {
      widget.offlineNetworkStatusController?.markOffline();
      if (mounted) setState(() {});
    }
  }

  Future<void> _onConnectivityChanged(List<ConnectivityResult> results) async {
    _hasNetworkConnectivity = results.any(
      (result) => result != ConnectivityResult.none,
    );
    final networkStatus = widget.offlineNetworkStatusController;
    if (!_hasNetworkConnectivity) {
      networkStatus?.markOffline();
      if (mounted) setState(() {});
      return;
    }

    final shiftState = _shiftsCubit.state;
    final hasOfflineSnapshot =
        shiftState is ShiftsActive && shiftState.shift.isOfflineSnapshot;
    if (networkStatus?.status == OfflineNetworkStatus.offline ||
        widget.user.isOfflineSession ||
        hasOfflineSnapshot) {
      networkStatus?.markChecking();
      if (mounted) setState(() {});
      await _verifyServerSession();
    }
  }

  Future<void> _retryRecoveryWhenOffline() async {
    if (!_hasNetworkConnectivity ||
        widget.offlineNetworkStatusController?.status !=
            OfflineNetworkStatus.offline) {
      return;
    }
    await _refreshConnectivity();
  }

  Future<void> _verifyServerSession() async {
    if (_isVerifyingServer || !mounted) return;
    _isVerifyingServer = true;
    final networkStatus = widget.offlineNetworkStatusController;
    try {
      final verified = await context
          .read<AuthCubit>()
          .verifyOfflineSalesSession();
      if (!mounted) return;
      if (verified) {
        await _shiftsCubit.refreshActive();
      } else if (networkStatus?.status == OfflineNetworkStatus.checking) {
        networkStatus?.markOffline();
      }
    } on Exception {
      if (networkStatus?.status == OfflineNetworkStatus.checking) {
        networkStatus?.markOffline();
      }
    } finally {
      _isVerifyingServer = false;
      if (mounted) setState(() {});
    }
  }

  Widget _pageAt(int index) {
    return switch (index) {
      0 => AdminDashboardPage(
        admin: widget.user,
        checkoutRepository: widget.checkoutRepository,
        onOpenCashier: () => _selectDestination(1),
        onOpenReport: () => _selectDestination(2),
        onOpenManagement: () => _selectDestination(1),
        isCashier: true,
      ),
      1 => OfflineSalesTab(
        admin: widget.user,
        offlineSalesRepositoryFactory: widget.offlineSalesRepositoryFactory,
        offlineTransactionQueueRepository:
            widget.offlineTransactionQueueRepository,
        offlineNetworkStatusController: widget.offlineNetworkStatusController,
        offlineTransactionSyncService: widget.offlineTransactionSyncService,
        autoCloseSettingsProvider: widget.autoCloseSettingsProvider,
      ),
      2 => AdminTransactionReportPage(
        checkoutRepository: widget.checkoutRepository,
        balancesRepository: widget.balancesRepository,
        canRecordExpenses: false,
      ),
      _ => const SizedBox.shrink(),
    };
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider.value(
      value: _shiftsCubit,
      child: Scaffold(
        body: IndexedStack(
          index: _selectedIndex,
          children: List.generate(
            _pages.length,
            (index) => _pages[index] ?? const SizedBox.shrink(),
          ),
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: _selectedIndex,
          onDestinationSelected: _selectDestination,
          destinations: const [
            NavigationDestination(
              icon: Icon(Icons.dashboard_outlined),
              selectedIcon: Icon(Icons.dashboard),
              label: 'Dashboard',
            ),
            NavigationDestination(
              icon: Icon(Icons.point_of_sale_outlined),
              selectedIcon: Icon(Icons.point_of_sale),
              label: 'Kasir',
            ),
            NavigationDestination(
              icon: Icon(Icons.receipt_long_outlined),
              selectedIcon: Icon(Icons.receipt_long),
              label: 'Laporan',
            ),
          ],
        ),
      ),
    );
  }

  void _selectDestination(int index) {
    setState(() {
      _selectedIndex = index;
      _pages[index] ??= _pageAt(index);
    });
  }
}
