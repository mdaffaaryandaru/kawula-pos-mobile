// Flutter imports:
import 'package:flutter/material.dart';

// Package imports:
import 'package:flutter_bloc/flutter_bloc.dart';

// Project imports:
import 'package:kawula_pos/features/auth/domain/entities/auth_user.dart';
import 'package:kawula_pos/features/products/data/repositories/cashier_cached_catalog_repository.dart';
import 'package:kawula_pos/features/products/domain/repositories/catalog_repository.dart';
import 'package:kawula_pos/features/products/presentation/bloc/cart_cubit.dart';
import 'package:kawula_pos/features/products/presentation/bloc/catalog_cubit.dart';
import 'package:kawula_pos/features/products/presentation/pages/catalog_page.dart';
import 'package:kawula_pos/features/shifts/presentation/bloc/shifts_cubit.dart';
import 'package:kawula_pos/features/shifts/presentation/bloc/shifts_state.dart';
import 'package:kawula_pos/features/shifts/domain/entities/active_shift.dart';
import 'package:kawula_pos/features/shifts/presentation/widgets/shift_action_dialog.dart';
import 'package:kawula_pos/features/transactions/data/repositories/cashier_cached_checkout_repository.dart';
import 'package:kawula_pos/features/transactions/data/repositories/cashier_offline_checkout_repository.dart';
import 'package:kawula_pos/features/transactions/data/services/cashier_offline_sync_service.dart';
import 'package:kawula_pos/features/transactions/domain/repositories/checkout_repository.dart';
import 'package:kawula_pos/features/transactions/presentation/pages/offline_transaction_queue_page.dart';
import 'package:kawula_pos/features/store_settings/domain/repositories/store_settings_repository.dart';
import 'package:kawula_pos/framework/core/offline/cashier_master_data_cache.dart';
import 'package:kawula_pos/framework/core/offline/database/daos/offline_transactions_dao.dart';
import 'package:kawula_pos/framework/core/offline/offline_sales_policy.dart';

class CashierTab extends StatelessWidget {
  const CashierTab({
    super.key,
    required this.admin,
    required this.catalogRepository,
    required this.checkoutRepository,
    this.offlineTransactionsDao,
    this.cashierOfflineSyncService,
    this.cashierMasterDataCache,
    this.storeSettingsRepository,
    this.catalogPageKey,
  });

  final AuthUser admin;
  final CatalogRepository catalogRepository;
  final CheckoutRepository checkoutRepository;
  final OfflineTransactionsDao? offlineTransactionsDao;
  final CashierOfflineSyncService? cashierOfflineSyncService;
  final CashierMasterDataCache? cashierMasterDataCache;
  final StoreSettingsRepository? storeSettingsRepository;
  final GlobalKey<CatalogPageState>? catalogPageKey;

  Future<int> _loadUnresolvedCount(
    ActiveShift activeShift,
    OfflineTransactionsDao dao,
  ) {
    final outletId = activeShift.outletId;
    if (outletId == null || outletId.trim().isEmpty) {
      throw StateError('Outlet shift tidak tersedia untuk memeriksa antrean.');
    }
    return dao
        .getUnresolvedTransactions(
          ownerUserId: admin.id,
          outletId: outletId,
          shiftId: activeShift.id,
        )
        .then((records) => records.length);
  }

  Widget _buildActiveShift(BuildContext context, ActiveShift shift) {
    final scopedCache = cashierMasterDataCache?.forRole(
      role: admin.role,
      userId: admin.id,
      outletId: shift.outletId,
    );
    final offlineTransactionsDao = this.offlineTransactionsDao;
    final cashierOfflineSyncService = this.cashierOfflineSyncService;

    final scopedCatalogRepository = scopedCache == null
        ? catalogRepository
        : CashierCachedCatalogRepository(
            catalogRepository,
            scopedCache,
            offlineTransactionsDao: offlineTransactionsDao,
          );
    final cachedCheckoutRepository = scopedCache == null
        ? checkoutRepository
        : CashierCachedCheckoutRepository(checkoutRepository, scopedCache);
    final scopedCheckoutRepository =
        scopedCache == null || offlineTransactionsDao == null
        ? cachedCheckoutRepository
        : CashierOfflineCheckoutRepository(
            cachedCheckoutRepository,
            scopedCache,
            offlineTransactionsDao,
            user: admin,
            shift: shift,
          );

    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (_) => CatalogCubit(scopedCatalogRepository)..load(),
        ),
        BlocProvider(create: (_) => CartCubit()),
      ],
      child: CatalogPage(
        key: catalogPageKey,
        user: admin,
        checkoutRepository: scopedCheckoutRepository,
        outletId: shift.outletId,
        activeShift: shift,
        offlineTransactionsDao: offlineTransactionsDao,
        cashierOfflineSyncService: cashierOfflineSyncService,
        storeSettingsRepository: storeSettingsRepository,
        cashierMasterDataCache: scopedCache,
        onManageShift: () {
          if (scopedCache != null &&
              scopedCache.networkStatus != CashierNetworkStatus.online) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Pengelolaan shift memerlukan koneksi internet.'),
              ),
            );
            return;
          }
          showShiftActionDialog(
            context,
            user: admin,
            mode: ShiftDialogMode.closing,
            loadUnresolvedOfflineTransactionCount:
                canUseOfflineSales(admin.role) && offlineTransactionsDao != null
                ? (activeShift) =>
                      _loadUnresolvedCount(activeShift, offlineTransactionsDao)
                : null,
            onOpenOfflineQueue:
                canUseOfflineSales(admin.role) &&
                    offlineTransactionsDao != null &&
                    cashierOfflineSyncService != null
                ? () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => OfflineTransactionQueuePage(
                          user: admin,
                          outletId: shift.outletId ?? '',
                          shiftId: shift.id,
                          dao: offlineTransactionsDao,
                          syncService: cashierOfflineSyncService,
                          cashierMasterDataCache: scopedCache,
                        ),
                      ),
                    );
                  }
                : null,
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<ShiftsCubit, ShiftsState>(
      builder: (context, state) => switch (state) {
        ShiftsLoading() => const Scaffold(
          appBar: CashierAppBar(),
          body: Center(child: CircularProgressIndicator()),
        ),
        ShiftsNeedsOpening()
            when cashierMasterDataCache != null &&
                cashierMasterDataCache!.networkStatus !=
                    CashierNetworkStatus.online =>
          _shiftRequiresConnection(context),
        ShiftsNeedsOpening() => Scaffold(
          appBar: const CashierAppBar(),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 420),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.lock_clock_outlined, size: 48),
                    const SizedBox(height: 16),
                    Text(
                      'Belum ada shift aktif',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Buka shift untuk mulai menggunakan kasir.',
                      textAlign: TextAlign.center,
                    ),
                    if (state.errorMessage != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        state.errorMessage!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.error,
                        ),
                      ),
                    ],
                    const SizedBox(height: 20),
                    FilledButton.icon(
                      onPressed: () => showShiftActionDialog(
                        context,
                        user: admin,
                        mode: ShiftDialogMode.opening,
                      ),
                      icon: const Icon(Icons.lock_open_rounded),
                      label: const Text('Open Shift'),
                    ),
                    TextButton(
                      onPressed: context.read<ShiftsCubit>().loadActive,
                      child: const Text('Perbarui status'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        ShiftsOpening() => Scaffold(
          appBar: const CashierAppBar(),
          body: const Center(child: CircularProgressIndicator()),
        ),
        ShiftsActive() => _buildActiveShift(context, state.shift),
        ShiftsClosing() => Scaffold(
          appBar: const CashierAppBar(),
          body: const Center(child: CircularProgressIndicator()),
        ),
        ShiftsClosed() => Scaffold(
          appBar: const CashierAppBar(),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.task_alt, size: 48, color: Colors.green),
                  const SizedBox(height: 12),
                  const Text('Shift berhasil ditutup'),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: context.read<ShiftsCubit>().loadActive,
                    child: const Text('Selesai'),
                  ),
                ],
              ),
            ),
          ),
        ),
        ShiftsFailure() => Scaffold(
          appBar: const CashierAppBar(),
          body: Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(Icons.cloud_off_outlined, size: 48),
                  const SizedBox(height: 16),
                  const Text(
                    'Shift belum dapat diperiksa',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 8),
                  Text(state.message, textAlign: TextAlign.center),
                  const SizedBox(height: 20),
                  FilledButton(
                    onPressed: context.read<ShiftsCubit>().loadActive,
                    child: const Text('Coba lagi'),
                  ),
                ],
              ),
            ),
          ),
        ),
      },
    );
  }

  Widget _shiftRequiresConnection(BuildContext context) => Scaffold(
    appBar: const CashierAppBar(),
    body: Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.cloud_off_outlined, size: 48),
            const SizedBox(height: 16),
            Text(
              'Shift aktif tidak tersedia secara lokal.',
              style: Theme.of(context).textTheme.titleLarge,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            const Text(
              'Buka shift harus dilakukan saat online sebelum Offline Sales.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    ),
  );
}

class CashierAppBar extends StatelessWidget implements PreferredSizeWidget {
  const CashierAppBar({super.key});

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);

  @override
  Widget build(BuildContext context) => AppBar(
    title: Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.asset(
            'assets/images/logo.jpg',
            width: 36,
            height: 36,
            fit: BoxFit.cover,
          ),
        ),
        const SizedBox(width: 10),
        const Text('Kasir'),
      ],
    ),
  );
}
