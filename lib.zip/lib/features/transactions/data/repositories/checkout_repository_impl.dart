// Project imports:
import 'package:kawula_pos/features/members/domain/entities/member.dart';
import 'package:kawula_pos/features/members/domain/entities/member_reward_claim.dart';
import 'package:kawula_pos/features/products/domain/entities/cart_item.dart';
import 'package:kawula_pos/features/transactions/data/datasources/checkout_remote_data_source.dart';
import 'package:kawula_pos/features/transactions/domain/entities/checkout.dart';
import 'package:kawula_pos/features/transactions/domain/repositories/checkout_repository.dart';

class CheckoutRepositoryImpl implements CheckoutRepository {
  const CheckoutRepositoryImpl(this._remoteDataSource);

  final CheckoutRemoteDataSource _remoteDataSource;

  @override
  Future<List<CheckoutPaymentMethod>> getPaymentMethods() {
    return _remoteDataSource.getPaymentMethods();
  }

  @override
  Future<CheckoutSettings> getSettings() => _remoteDataSource.getSettings();

  @override
  Future<List<TransactionRecord>> getTransactions() {
    return _remoteDataSource.getTransactions();
  }

  @override
  Future<TransactionRecord> getTransaction(String transactionId) =>
      _remoteDataSource.getTransaction(transactionId);

  @override
  Future<TransactionRecord> cancelTransaction({
    required String transactionId,
    required String reason,
  }) => _remoteDataSource.cancelTransaction(
    transactionId: transactionId,
    reason: reason,
  );

  @override
  Future<TransactionRecord> refundTransaction({
    required String transactionId,
    required String pin,
    required String reason,
  }) => _remoteDataSource.refundTransaction(
    transactionId: transactionId,
    pin: pin,
    reason: reason,
  );

  @override
  Future<List<Member>> searchMembers(String search) =>
      _remoteDataSource.searchMembers(search);

  @override
  Future<MemberRewardClaim> claimMemberReward(String memberId) =>
      _remoteDataSource.claimMemberReward(memberId);

  @override
  Future<CheckoutResult> payPendingTransaction({
    required String transactionId,
    required String paymentMethod,
    required num paidAmount,
    required String pin,
  }) {
    return _remoteDataSource.payPendingTransaction(
      transactionId: transactionId,
      paymentMethod: paymentMethod,
      paidAmount: paidAmount,
      pin: pin,
    );
  }

  @override
  Future<CheckoutResult> createTransaction({
    required String outletId,
    required List<CartItem> items,
    required num estimatedTotal,
    required num serviceCharge,
    required String paymentMethod,
    required num paidAmount,
    required String? pin,
    required bool openBill,
    String? memberId,
    String? tableNumber,
  }) {
    return _remoteDataSource.createTransaction(
      outletId: outletId,
      items: items,
      estimatedTotal: estimatedTotal,
      serviceCharge: serviceCharge,
      paymentMethod: paymentMethod,
      paidAmount: paidAmount,
      pin: pin,
      openBill: openBill,
      memberId: memberId,
      tableNumber: tableNumber,
    );
  }
}
