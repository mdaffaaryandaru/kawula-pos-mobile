// Project imports:
import 'package:kawula_pos/features/members/domain/entities/member.dart';
import 'package:kawula_pos/features/members/domain/entities/member_reward_claim.dart';
import 'package:kawula_pos/features/products/domain/entities/cart_item.dart';
import 'package:kawula_pos/features/transactions/domain/entities/checkout.dart';

abstract interface class CheckoutRepository {
  Future<List<CheckoutPaymentMethod>> getPaymentMethods();

  Future<CheckoutSettings> getSettings();

  Future<List<TransactionRecord>> getTransactions();

  Future<TransactionRecord> getTransaction(String transactionId);

  Future<TransactionRecord> cancelTransaction({
    required String transactionId,
    required String reason,
  });

  Future<TransactionRecord> refundTransaction({
    required String transactionId,
    required String pin,
    required String reason,
  });

  Future<List<Member>> searchMembers(String search);

  Future<MemberRewardClaim> claimMemberReward(String memberId);

  Future<CheckoutResult> payPendingTransaction({
    required String transactionId,
    required String paymentMethod,
    required num paidAmount,
    required String pin,
  });

  Future<CheckoutResult> createTransaction({
    required String outletId,
    required List<CartItem> items,
    required num estimatedTotal,
    required num serviceCharge,
    required String paymentMethod,
    required num paidAmount,
    required String? pin,
    required bool openBill,
    String? memberId,
    String? tableNumber,
  });
}

abstract interface class CheckoutModeProvider {
  bool get isOffline;
}
