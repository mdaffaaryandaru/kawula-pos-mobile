import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import 'package:kawula_pos/features/products/domain/entities/cart_item.dart';
import 'package:kawula_pos/features/products/domain/entities/catalog_product.dart';
import 'package:kawula_pos/features/shifts/domain/repositories/shifts_repository.dart';
import 'package:kawula_pos/features/offline/domain/entities/offline_transaction_sync_summary.dart';
import 'package:kawula_pos/features/transactions/domain/repositories/checkout_repository.dart';
import 'package:kawula_pos/features/offline/domain/services/offline_transaction_sync.dart';
import 'package:kawula_pos/framework/core/exceptions/api_exception.dart';
import 'package:kawula_pos/features/offline/data/database/app_database.dart';
import 'package:kawula_pos/features/offline/data/database/daos/offline_transactions_dao.dart';
import 'package:kawula_pos/features/offline/domain/policies/offline_sales_policy.dart';

export 'package:kawula_pos/features/offline/domain/entities/offline_transaction_sync_summary.dart';

enum _SyncResult {
  success,
  failed,
  needsReconciliation,
  stopPin,
  stopAuthentication,
  stopAuthorization,
}

class OfflineTransactionSyncService implements OfflineTransactionSync {
  OfflineTransactionSyncService(
    this._repository,
    this._dao, {
    required this._activeShiftsRepository,
  });

  final CheckoutRepository _repository;
  final OfflineTransactionsDao _dao;
  final ShiftsRepository _activeShiftsRepository;
  bool _isSyncing = false;

  @override
  bool get isSyncing => _isSyncing;

  @override
  Future<OfflineTransactionSyncSummary> syncOfflineTransactions({
    required String ownerUserId,
    required String outletId,
    required String role,
    required String pin,
  }) async {
    if (!canUseOfflineSales(role)) {
      throw StateError('Role tidak diizinkan melakukan Offline Sales.');
    }
    if (ownerUserId.trim().isEmpty) {
      throw ArgumentError.value(
        ownerUserId,
        'ownerUserId',
        'Pemilik antrean wajib ditentukan.',
      );
    }
    if (outletId.trim().isEmpty) {
      throw ArgumentError.value(
        outletId,
        'outletId',
        'Outlet aktif wajib ditentukan.',
      );
    }
    if (pin.trim().isEmpty) {
      throw ArgumentError.value(
        pin,
        'pin',
        'PIN wajib dimasukkan untuk pengiriman data.',
      );
    }
    if (_isSyncing) {
      final queue = await _dao.getUnresolvedByOwnerAndOutlet(
        ownerUserId: ownerUserId,
        outletId: outletId,
      );
      return _summaryFor(
        queue,
        stopped: true,
        stopReason: 'Pengiriman data lain sedang berjalan.',
      );
    }

    _isSyncing = true;
    var successCount = 0;
    var failedCount = 0;
    String? stopReason;

    try {
      var queue = await _dao.getUnresolvedByOwnerAndOutlet(
        ownerUserId: ownerUserId,
        outletId: outletId,
      );
      if (queue.isEmpty) {
        return _summaryFor(queue, stopped: false, stopReason: null);
      }

      final existingFailedCount = queue
          .where(
            (transaction) =>
                transaction.status ==
                OfflineTransactionStatus.failed.databaseValue,
          )
          .length;
      final stuckSyncing = queue
          .where(
            (transaction) =>
                transaction.status ==
                OfflineTransactionStatus.syncing.databaseValue,
          )
          .toList(growable: false);
      for (final transaction in stuckSyncing) {
        await _dao.updateTransactionStatus(
          localId: transaction.localId,
          status: OfflineTransactionStatus.needsReconciliation,
          lastError: 'Proses pengiriman data sebelumnya terputus saat transaksi berstatus syncing. Verifikasi transaksi di server sebelum tindakan lanjutan.',
        );
      }

      queue = await _dao.getUnresolvedByOwnerAndOutlet(
        ownerUserId: ownerUserId,
        outletId: outletId,
      );
      final needsReconciliation = queue
          .where(
            (transaction) =>
                transaction.status ==
                OfflineTransactionStatus.needsReconciliation.databaseValue,
          )
          .toList(growable: false);
      if (needsReconciliation.isNotEmpty) {
        return _summaryFor(
          queue,
          existingFailedCount: existingFailedCount,
          stopped: true,
          stopReason: 'Terdapat transaksi yang menunggu pencocokan.',
        );
      }

      final pendingRecords = queue
          .where(
            (transaction) =>
                transaction.status ==
                OfflineTransactionStatus.pendingSync.databaseValue,
          )
          .toList(growable: false);

      if (pendingRecords.isNotEmpty) {
        try {
          final activeShift = await _activeShiftsRepository.getActive();
          if (activeShift == null ||
              activeShift.status.toLowerCase() != 'open' ||
              activeShift.outletId != outletId ||
              activeShift.isOfflineSnapshot) {
            return _summaryFor(
              queue,
              existingFailedCount: existingFailedCount,
              stopped: true,
              stopReason: 'Pengiriman data memerlukan shift aktif online pada outlet yang sedang dipakai. Shift asal transaksi tetap tersimpan sebagai riwayat.',
            );
          }
        } catch (error) {
          return _summaryFor(
            queue,
            existingFailedCount: existingFailedCount,
            stopped: true,
            stopReason: 'Shift aktif server belum dapat diverifikasi: $error',
          );
        }
      }

      for (final record in pendingRecords) {
        final payload = _decodePayload(record.payloadJson);
        if (payload == null) {
          await _dao.updateTransactionStatus(
            localId: record.localId,
            status: OfflineTransactionStatus.failed,
            lastError: 'Payload transaksi lokal tidak valid dan belum dikirim.',
          );
          failedCount++;
          continue;
        }

        final List<CartItem> items;
        try {
          _validatePayload(record, payload);
          items = _buildCartItems(payload['items']);
        } on FormatException catch (error) {
          await _dao.updateTransactionStatus(
            localId: record.localId,
            status: OfflineTransactionStatus.failed,
            lastError:
                'Payload transaksi lokal tidak valid dan belum dikirim: ${error.message}',
          );
          failedCount++;
          continue;
        }

        await _dao.updateTransactionStatus(
          localId: record.localId,
          status: OfflineTransactionStatus.syncing,
          incrementAttemptCount: true,
        );

        final result = await _sendRecord(record, payload, items, pin);
        switch (result) {
          case _SyncResult.success:
            successCount++;
            break;
          case _SyncResult.failed:
            failedCount++;
            break;
          case _SyncResult.needsReconciliation:
            stopReason =
                'Respons server tidak dapat dipastikan dan antrean dihentikan.';
            break;
          case _SyncResult.stopPin:
            stopReason =
                'PIN ditolak. Masukkan PIN yang benar untuk mencoba kembali.';
            break;
          case _SyncResult.stopAuthentication:
            stopReason = 'Sesi autentikasi kedaluwarsa.';
            break;
          case _SyncResult.stopAuthorization:
            failedCount++;
            stopReason = 'Akses ditolak oleh server.';
            break;
        }

        if (result != _SyncResult.success && result != _SyncResult.failed) {
          break;
        }
      }

      final remainingQueue = await _dao.getUnresolvedByOwnerAndOutlet(
        ownerUserId: ownerUserId,
        outletId: outletId,
      );
      return _summaryFor(
        remainingQueue,
        successCount: successCount,
        failedCount: failedCount,
        existingFailedCount: existingFailedCount,
        stopped: stopReason != null,
        stopReason: stopReason,
      );
    } finally {
      _isSyncing = false;
    }
  }

  OfflineTransactionSyncSummary _summaryFor(
    List<OfflineTransaction> queue, {
    int successCount = 0,
    int failedCount = 0,
    int? existingFailedCount,
    required bool stopped,
    required String? stopReason,
  }) => OfflineTransactionSyncSummary(
    successCount: successCount,
    failedCount: failedCount,
    existingFailedCount:
        existingFailedCount ??
        queue
            .where(
              (transaction) =>
                  transaction.status ==
                  OfflineTransactionStatus.failed.databaseValue,
            )
            .length,
    pendingCount: queue
        .where(
          (transaction) =>
              transaction.status ==
              OfflineTransactionStatus.pendingSync.databaseValue,
        )
        .length,
    needsReconciliationCount: queue
        .where(
          (transaction) =>
              transaction.status ==
              OfflineTransactionStatus.needsReconciliation.databaseValue,
        )
        .length,
    unresolvedCount: queue.length,
    stopped: stopped,
    stopReason: stopReason,
  );

  Future<_SyncResult> _sendRecord(
    OfflineTransaction transaction,
    Map<String, dynamic> payload,
    List<CartItem> items,
    String pin,
  ) async {
    final totalAmount = _asNum(payload['total_amount']) ?? 0;
    final serviceCharge = _asNum(payload['service_charge']) ?? 0;
    final paymentMethod = _asString(payload['payment_method']) ?? 'CASH';
    final paidAmount = _asNum(payload['paid_amount']) ?? 0;
    final openBill =
        transaction.transactionType == 'open_bill' ||
        paymentMethod.toUpperCase() == 'OPEN_BILL';

    try {
      final result = await _repository.createTransaction(
        outletId: transaction.outletId,
        items: items,
        estimatedTotal: totalAmount,
        serviceCharge: serviceCharge,
        paymentMethod: paymentMethod,
        paidAmount: paidAmount,
        pin: openBill ? null : pin,
        openBill: openBill,
        memberId: _asString(payload['member_id']),
        tableNumber: _asString(payload['table_number']),
      );

      final remoteId = result.id.trim();
      if (remoteId.isEmpty || remoteId.startsWith('OFF-')) {
        await _dao.updateTransactionStatus(
          localId: transaction.localId,
          status: OfflineTransactionStatus.needsReconciliation,
          lastError: 'Respons server tidak menyertakan ID transaksi remote yang valid.',
        );
        return _SyncResult.needsReconciliation;
      }

      await _dao.updateTransactionStatus(
        localId: transaction.localId,
        status: OfflineTransactionStatus.synced,
        remoteTransactionId: remoteId,
        lastError: null,
      );
      return _SyncResult.success;
    } on ApiException catch (error) {
      if (error.statusCode == 401) {
        await _dao.updateTransactionStatus(
          localId: transaction.localId,
          status: OfflineTransactionStatus.pendingSync,
          lastError:
              'Sesi autentikasi kedaluwarsa. Pengiriman data dihentikan.',
        );
        return _SyncResult.stopAuthentication;
      }
      if (_isPinRejection(error)) {
        await _dao.updateTransactionStatus(
          localId: transaction.localId,
          status: OfflineTransactionStatus.pendingSync,
          lastError:
              'PIN kasir ditolak (${error.statusCode}: ${error.message}). '
              'Pengiriman data dihentikan.',
        );
        return _SyncResult.stopPin;
      }
      if (error.statusCode == 403) {
        await _dao.updateTransactionStatus(
          localId: transaction.localId,
          status: OfflineTransactionStatus.failed,
          lastError: error.message,
        );
        return _SyncResult.stopAuthorization;
      }
      if (error.statusCode == 400) {
        await _dao.updateTransactionStatus(
          localId: transaction.localId,
          status: OfflineTransactionStatus.failed,
          lastError: error.message,
        );
        return _SyncResult.failed;
      }
      await _dao.updateTransactionStatus(
        localId: transaction.localId,
        status: OfflineTransactionStatus.needsReconciliation,
        lastError: error.message,
      );
      return _SyncResult.needsReconciliation;
    } on http.ClientException catch (error) {
      await _dao.updateTransactionStatus(
        localId: transaction.localId,
        status: OfflineTransactionStatus.needsReconciliation,
        lastError: error.toString(),
      );
      return _SyncResult.needsReconciliation;
    } on TimeoutException catch (error) {
      await _dao.updateTransactionStatus(
        localId: transaction.localId,
        status: OfflineTransactionStatus.needsReconciliation,
        lastError: error.toString(),
      );
      return _SyncResult.needsReconciliation;
    } catch (error) {
      await _dao.updateTransactionStatus(
        localId: transaction.localId,
        status: OfflineTransactionStatus.needsReconciliation,
        lastError: error.toString(),
      );
      return _SyncResult.needsReconciliation;
    }
  }

  Map<String, dynamic>? _decodePayload(String rawPayload) {
    try {
      final decoded = jsonDecode(rawPayload);
      if (decoded is Map<String, dynamic>) {
        return decoded;
      }
      if (decoded is Map) {
        return Map<String, dynamic>.from(decoded);
      }
      return null;
    } on FormatException {
      return null;
    }
  }

  List<CartItem> _buildCartItems(Object? rawItems) {
    if (rawItems is! List || rawItems.isEmpty) {
      throw const FormatException('Payload item transaksi tidak valid.');
    }

    final items = <CartItem>[];
    for (final rawItem in rawItems) {
      if (rawItem is! Map<String, dynamic>) {
        throw const FormatException('Item transaksi lokal tidak valid.');
      }
      final productId = rawItem['product_id'];
      final quantity = rawItem['quantity'];
      if (productId is! String ||
          productId.trim().isEmpty ||
          quantity is! num ||
          !quantity.isFinite ||
          quantity <= 0 ||
          quantity != quantity.toInt()) {
        throw const FormatException(
          'Rincian item transaksi lokal tidak valid.',
        );
      }
      final product = CatalogProduct(
        id: productId,
        name: rawItem['product_name'] is String
            ? rawItem['product_name'] as String
            : productId,
        price: _asNum(rawItem['unit_price']) ?? 0,
        imageUrl: '',
        isActive: true,
        category: null,
        variantGroups: const [],
      );
      final selectedVariants = <SelectedProductVariant>[];
      final variantPayload = rawItem['selected_variants'];
      if (variantPayload != null && variantPayload is! List) {
        throw const FormatException(
          'Daftar varian transaksi lokal tidak valid.',
        );
      }
      if (variantPayload is List) {
        for (final rawVariant in variantPayload) {
          if (rawVariant is! Map<String, dynamic> ||
              rawVariant['group_name'] is! String ||
              rawVariant['option_name'] is! String ||
              (rawVariant['option_id'] != null &&
                  rawVariant['option_id'] is! String)) {
            throw const FormatException(
              'Rincian varian transaksi lokal tidak valid.',
            );
          }
          selectedVariants.add(
            SelectedProductVariant(
              groupName: rawVariant['group_name'] as String,
              optionName: rawVariant['option_name'] as String,
              optionId: _asString(rawVariant['option_id']),
              priceAdjustment: _asNum(rawVariant['price_adjustment']) ?? 0,
            ),
          );
        }
      }
      if (rawItem['notes'] != null && rawItem['notes'] is! String) {
        throw const FormatException(
          'Catatan item transaksi lokal tidak valid.',
        );
      }

      items.add(
        CartItem(
          product: product,
          quantity: quantity.toInt(),
          selectedVariants: selectedVariants,
          notes: rawItem['notes'] is String ? rawItem['notes'] as String : '',
        ),
      );
    }
    return items;
  }

  void _validatePayload(
    OfflineTransaction transaction,
    Map<String, dynamic> payload,
  ) {
    final totalAmount = payload['total_amount'];
    final serviceCharge = payload['service_charge'];
    final paymentMethod = payload['payment_method'];
    if (totalAmount is! num ||
        !totalAmount.isFinite ||
        paymentMethod is! String ||
        paymentMethod.trim().isEmpty ||
        (serviceCharge != null &&
            (serviceCharge is! num || !serviceCharge.isFinite))) {
      throw const FormatException(
        'Total, biaya layanan, atau metode pembayaran lokal tidak valid.',
      );
    }

    final isOpenBill = transaction.transactionType == 'open_bill';
    if (!isOpenBill && transaction.transactionType != 'sale') {
      throw const FormatException('Jenis transaksi lokal tidak valid.');
    }
    if (isOpenBill != (paymentMethod.trim().toUpperCase() == 'OPEN_BILL')) {
      throw const FormatException(
        'Jenis transaksi tidak sesuai metode pembayaran lokal.',
      );
    }

    final paidAmount = payload['paid_amount'];
    if ((!isOpenBill && paidAmount is! num) ||
        (paidAmount != null && (paidAmount is! num || !paidAmount.isFinite))) {
      throw const FormatException('Nominal pembayaran lokal tidak valid.');
    }

    for (final optionalField in ['member_id', 'table_number']) {
      if (payload[optionalField] != null && payload[optionalField] is! String) {
        throw FormatException(
          'Data $optionalField transaksi lokal tidak valid.',
        );
      }
    }
  }

  String? _asString(Object? value) => value is String ? value : null;

  num? _asNum(Object? value) => value is num ? value : null;

  // Pesan PIN salah dari backend, sudah dinormalisasi (huruf kecil, tanpa
  // tanda baca di ujung). Backend mengirim: 400 "PIN salah".
  static const _knownPinRejectedMessages = {'pin salah'};

  String _normalizeMessage(String message) =>
      message.trim().toLowerCase().replaceAll(RegExp(r'[.!\s]+$'), '');

  bool _isPinRejection(ApiException error) {
    final status = error.statusCode;
    if (status != 400 && status != 403) return false;
    final message = _normalizeMessage(error.message);
    if (_knownPinRejectedMessages.contains(message)) return true;
    // Fail-safe: menyebut "pin" tetapi belum dikenal -> tetap pending_sync,
    // bukan failed.
    return RegExp(r'\bpin\b').hasMatch(message);
  }
}
