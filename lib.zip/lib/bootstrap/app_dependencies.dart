// Package imports:
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

// Project imports:
import 'package:kawula_pos/config/api_config.dart';
import 'package:kawula_pos/features/auth/data/datasources/auth_local_data_source.dart';
import 'package:kawula_pos/features/auth/data/datasources/auth_remote_data_source.dart';
import 'package:kawula_pos/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:kawula_pos/features/auth/domain/repositories/auth_repository.dart';
import 'package:kawula_pos/features/dashboard/application/admin_dependencies.dart';
import 'package:kawula_pos/features/balances/data/datasources/balances_remote_data_source.dart';
import 'package:kawula_pos/features/balances/data/repositories/balances_repository_impl.dart';
import 'package:kawula_pos/features/balances/domain/repositories/balances_repository.dart';
import 'package:kawula_pos/features/categories/data/datasources/categories_remote_data_source.dart';
import 'package:kawula_pos/features/categories/data/repositories/categories_repository_impl.dart';
import 'package:kawula_pos/features/discounts/data/datasources/discounts_remote_data_source.dart';
import 'package:kawula_pos/features/discounts/data/repositories/discounts_repository_impl.dart';
import 'package:kawula_pos/features/inventories/data/datasources/inventory_remote_data_source.dart';
import 'package:kawula_pos/features/inventories/data/repositories/inventory_repository_impl.dart';
import 'package:kawula_pos/features/members/data/datasources/members_remote_data_source.dart';
import 'package:kawula_pos/features/members/data/repositories/members_repository_impl.dart';
import 'package:kawula_pos/features/membership_programs/data/datasources/membership_programs_remote_data_source.dart';
import 'package:kawula_pos/features/membership_programs/data/repositories/membership_programs_repository_impl.dart';
import 'package:kawula_pos/features/offline/domain/services/offline_network_status_controller.dart';
import 'package:kawula_pos/features/outlets/data/datasources/outlets_remote_data_source.dart';
import 'package:kawula_pos/features/outlets/data/repositories/outlets_repository_impl.dart';
import 'package:kawula_pos/features/payment_method/data/datasources/payment_methods_remote_data_source.dart';
import 'package:kawula_pos/features/payment_method/data/repositories/payment_methods_repository_impl.dart';
import 'package:kawula_pos/features/product_units/data/datasources/product_units_remote_data_source.dart';
import 'package:kawula_pos/features/product_units/data/repositories/product_units_repository_impl.dart';
import 'package:kawula_pos/features/products/data/datasources/catalog_remote_data_source.dart';
import 'package:kawula_pos/features/products/data/datasources/product_management_remote_data_source.dart';
import 'package:kawula_pos/features/products/data/repositories/catalog_repository_impl.dart';
import 'package:kawula_pos/features/products/data/repositories/product_management_repository_impl.dart';
import 'package:kawula_pos/features/shifts/data/datasources/shifts_remote_data_source.dart';
import 'package:kawula_pos/features/shifts/data/repositories/shifts_repository_impl.dart';
import 'package:kawula_pos/features/store_settings/data/datasources/store_settings_remote_data_source.dart';
import 'package:kawula_pos/features/store_settings/data/repositories/auto_close_settings_provider_impl.dart';
import 'package:kawula_pos/features/store_settings/data/repositories/store_settings_repository_impl.dart';
import 'package:kawula_pos/features/store_settings/domain/repositories/auto_close_settings_provider.dart';
import 'package:kawula_pos/features/table_areas/data/datasources/table_areas_remote_data_source.dart';
import 'package:kawula_pos/features/table_areas/data/repositories/table_areas_repository_impl.dart';
import 'package:kawula_pos/features/tables/data/datasources/tables_remote_data_source.dart';
import 'package:kawula_pos/features/tables/data/repositories/tables_repository_impl.dart';
import 'package:kawula_pos/features/transactions/data/datasources/checkout_remote_data_source.dart';
import 'package:kawula_pos/features/transactions/data/repositories/checkout_repository_impl.dart';
import 'package:kawula_pos/features/offline/data/repositories/offline_transaction_queue_repository_impl.dart';
import 'package:kawula_pos/bootstrap/offline_sales_repository_factory_impl.dart';
import 'package:kawula_pos/features/offline/data/services/admin_offline_resolution_service.dart';
import 'package:kawula_pos/features/offline/data/services/offline_transaction_sync_service.dart';
import 'package:kawula_pos/features/transactions/domain/repositories/checkout_repository.dart';
import 'package:kawula_pos/features/offline/domain/repositories/offline_transaction_queue_repository.dart';
import 'package:kawula_pos/features/offline/application/offline_sales_repository_factory.dart';
import 'package:kawula_pos/features/offline/domain/services/offline_transaction_sync.dart';
import 'package:kawula_pos/features/users/data/datasources/users_remote_data_source.dart';
import 'package:kawula_pos/features/users/data/repositories/user_management_repository_impl.dart';
import 'package:kawula_pos/features/variant_groups/data/datasources/variant_groups_remote_data_source.dart';
import 'package:kawula_pos/features/variant_groups/data/repositories/variant_groups_repository_impl.dart';
import 'package:kawula_pos/framework/core/network/auth_session_expiry_handler.dart';
import 'package:kawula_pos/framework/core/network/session_aware_http_client.dart';
import 'package:kawula_pos/framework/core/network/http_client_factory.dart';
import 'package:kawula_pos/framework/core/network/timeout_http_client.dart';
import 'package:kawula_pos/features/offline/data/database/app_database.dart';
import 'package:kawula_pos/features/offline/data/cache/offline_master_data_cache.dart';

class AppDependencies {
  const AppDependencies({
    this.database,
    this.offlineNetworkStatusController,
    required this.authRepository,
    this.sessionExpiryHandler,
    required this.adminDependencies,
    required this.checkoutRepository,
    required this.offlineTransactionQueueRepository,
    required this.offlineSalesRepositoryFactory,
    this.offlineTransactionSyncService,
    required this.balancesRepository,
    required this.autoCloseSettingsProvider,
  });

  factory AppDependencies.create() {
    final sessionExpiryHandler = AuthSessionExpiryHandler();
    final client = SessionAwareHttpClient(
      TimeoutHttpClient(createPlatformHttpClient()),
      sessionExpiryHandler,
    );
    final apiBaseUrl = ApiConfig.baseUrl;
    final database = AppDatabase();
    final masterDataCache = OfflineMasterDataCache(database.cachedRecordsDao);
    final remoteDataSource = AuthRemoteDataSource(client, apiBaseUrl);
    final localDataSource = AuthLocalDataSource(const FlutterSecureStorage());
    final authRepository = AuthRepositoryImpl(
      remoteDataSource,
      localDataSource,
      sessionExpiryHandler: sessionExpiryHandler,
      masterDataCache: masterDataCache,
    );
    final catalogRepository = CatalogRepositoryImpl(
      CatalogRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final shiftsRepository = ShiftsRepositoryImpl(
      ShiftsRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final membersRemoteDataSource = MembersRemoteDataSource(
      client,
      apiBaseUrl,
      localDataSource.readToken,
    );
    final membersRepository = MembersRepositoryImpl(membersRemoteDataSource);
    final membershipProgramsRepository = MembershipProgramsRepositoryImpl(
      MembershipProgramsRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
      ),
    );
    final checkoutRepository = CheckoutRepositoryImpl(
      CheckoutRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
        membersRemoteDataSource: membersRemoteDataSource,
      ),
    );
    final offlineTransactionSyncService = OfflineTransactionSyncService(
      checkoutRepository,
      database.offlineTransactionsDao,
      activeShiftsRepository: shiftsRepository,
    );
    final offlineTransactionQueueRepository =
        OfflineTransactionQueueRepositoryImpl(database.offlineTransactionsDao);
    final offlineTransactionReconciliation = AdminOfflineResolutionService(
      queueRepository: offlineTransactionQueueRepository,
      checkoutRepository: checkoutRepository,
    );
    final offlineSalesRepositoryFactory = OfflineSalesRepositoryFactoryImpl(
      catalogRepository: catalogRepository,
      checkoutRepository: checkoutRepository,
      shiftsRepository: shiftsRepository,
      masterDataCache: masterDataCache,
      offlineTransactionsDao: database.offlineTransactionsDao,
    );
    final balancesRepository = BalancesRepositoryImpl(
      BalancesRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final storeSettingsRepository = StoreSettingsRepositoryImpl(
      StoreSettingsRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
      ),
      cacheDao: database.cachedRecordsDao,
    );
    final autoCloseSettingsProvider = AutoCloseSettingsProviderImpl(
      repository: storeSettingsRepository,
      masterDataCache: masterDataCache,
    );
    final userManagementRepository = UserManagementRepositoryImpl(
      UsersRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final categoriesRepository = CategoriesRepositoryImpl(
      CategoriesRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final discountsRepository = DiscountsRepositoryImpl(
      DiscountsRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final paymentMethodsRepository = PaymentMethodsRepositoryImpl(
      PaymentMethodsRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
      ),
    );
    final inventoryRepository = InventoryRepositoryImpl(
      InventoryRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final productUnitsRepository = ProductUnitsRepositoryImpl(
      ProductUnitsRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
      ),
    );
    final variantGroupsRepository = VariantGroupsRepositoryImpl(
      VariantGroupsRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
      ),
      productUnitsRepository,
    );
    final productManagementRepository = ProductManagementRepositoryImpl(
      ProductManagementRemoteDataSource(
        client,
        apiBaseUrl,
        localDataSource.readToken,
      ),
      categoriesRepository,
      variantGroupsRepository,
      inventoryRepository,
      productUnitsRepository,
    );
    final outletsRepository = OutletsRepositoryImpl(
      OutletsRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final tableAreasRepository = TableAreasRepositoryImpl(
      TableAreasRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );
    final tablesRepository = TablesRepositoryImpl(
      TablesRemoteDataSource(client, apiBaseUrl, localDataSource.readToken),
    );

    return AppDependencies(
      database: database,
      offlineNetworkStatusController: masterDataCache,
      authRepository: authRepository,
      sessionExpiryHandler: sessionExpiryHandler,
      adminDependencies: AdminDependencies(
        apiBaseUrl: apiBaseUrl,
        catalogRepository: catalogRepository,
        offlineTransactionReconciliation: offlineTransactionReconciliation,
        storeSettingsRepository: storeSettingsRepository,
        userManagementRepository: userManagementRepository,
        productManagementRepository: productManagementRepository,
        categoriesRepository: categoriesRepository,
        variantGroupsRepository: variantGroupsRepository,
        discountsRepository: discountsRepository,
        paymentMethodsRepository: paymentMethodsRepository,
        inventoryRepository: inventoryRepository,
        productUnitsRepository: productUnitsRepository,
        outletsRepository: outletsRepository,
        tableAreasRepository: tableAreasRepository,
        tablesRepository: tablesRepository,
        membersRepository: membersRepository,
        membershipProgramsRepository: membershipProgramsRepository,
      ),
      checkoutRepository: checkoutRepository,
      offlineTransactionQueueRepository: offlineTransactionQueueRepository,
      offlineSalesRepositoryFactory: offlineSalesRepositoryFactory,
      offlineTransactionSyncService: offlineTransactionSyncService,
      balancesRepository: balancesRepository,
      autoCloseSettingsProvider: autoCloseSettingsProvider,
    );
  }

  final AppDatabase? database;
  final OfflineNetworkStatusController? offlineNetworkStatusController;
  final AuthRepository authRepository;
  final AuthSessionExpiryHandler? sessionExpiryHandler;
  final AdminDependencies adminDependencies;
  final CheckoutRepository checkoutRepository;
  final OfflineTransactionQueueRepository offlineTransactionQueueRepository;
  final OfflineSalesRepositoryFactory offlineSalesRepositoryFactory;
  final OfflineTransactionSync? offlineTransactionSyncService;
  final BalancesRepository balancesRepository;
  final AutoCloseSettingsProvider autoCloseSettingsProvider;

  Future<void> close() async {
    await database?.close();
  }
}
